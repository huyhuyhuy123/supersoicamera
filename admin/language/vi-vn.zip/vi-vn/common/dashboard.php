<?php
// Heading
$_['heading_title'] = 'Bảng điểu khiển';

// Error
$_['error_install']                = 'Cảnh báo: thư mục Install vẫn còn tồn tại , bạn nên xóa đi vì lý do bảo mật!';