<?php
// Text
$_['text_footer']  = '<a href="/">Supersoicamera.com</a> &copy; ' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Phiên bản %s';