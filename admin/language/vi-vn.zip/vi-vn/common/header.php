<?php
// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = 'Hồ sơ của bạn';
$_['text_store']         = 'Cửa hàng';
$_['text_help']          = 'Hỗ trợ';
$_['text_homepage']      = 'Trang chủ OpenCart';
$_['text_support']       = 'Diễn đàn hỗ trợ';
$_['text_documentation'] = 'Tài liệu';
$_['text_logout']        = 'Đăng xuất';