<?php
// Heading
$_['heading_title']    = 'Captcha cơ bản';

// Text
$_['text_extension']   = 'Tiện ích mở rộng';
$_['text_success']     = 'Thành công: Bạn đã sửa đổi Captcha cơ bản!';
$_['text_edit']        = 'Chỉnh sửa Captcha cơ bản';

// Entry
$_['entry_status']     = 'Tình trạng';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi Captcha cơ bản!';