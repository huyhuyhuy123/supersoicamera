<?php
// Text
$_['text_subject'] = '%s - Tài khoản của bạn đã được kích hoạt!';
$_['text_welcome'] = 'Chào mừng và cảm ơn bạn đã đăng ký tại %s!';
$_['text_login']   = 'Tài khoản của bạn đã được tạo và bạn có thể đăng nhập bằng cách sử dụng địa chỉ email và mật khẩu bằng cách truy cập trang web của chúng tôi hoặc tại URL sau:';
$_['text_service'] = 'Khi đăng nhập, bạn sẽ có thể truy cập vào các dịch vụ khác bao gồm xem xét đơn đặt hàng trong quá khứ, in hoá đơn và chỉnh sửa thông tin tài khoản của bạn.';
$_['text_thanks']  = 'Cảm ơn,';