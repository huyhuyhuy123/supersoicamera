<?php
// Text
$_['text_subject']  = '%s - Tín Dụng đại lý';
$_['text_received'] = 'Bạn đã nhận được %s Tin dụng!';
$_['text_total']    = 'Tổng số tín dụng của bạn bây giờ %s.';
$_['text_credit']   = 'Tín dụng tài khoản của bạn có thể được khấu trừ từ lần mua tiếp theo.';