<?php
// Heading
$_['heading_title'] = 'Báo cáo';

// Text
$_['text_success']  = 'Thành công: Bạn đã sửa đổi báo cáo!';
$_['text_list']     = 'Danh sách Báo cáo';
$_['text_type']     = 'Chọn loại báo cáo';
$_['text_filter']   = 'Chọn bộ lọc';