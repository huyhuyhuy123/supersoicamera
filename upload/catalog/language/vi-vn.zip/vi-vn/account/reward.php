<?php
// Heading
$_['heading_title']      = 'Điểm Thưởng Của Bạn';

// Column
$_['column_date_added']  = 'Ngày Thêm';
$_['column_description'] = 'Mô Tả';
$_['column_points']      = 'Điểm';

// Text
$_['text_account']       = 'Tài khoản';
$_['text_reward']        = 'Điểm thưởng';
$_['text_total']         = 'Tổng điểm thưởng của bạn là:';
$_['text_empty']         = 'Bạn không có điểm thưởng nào!';