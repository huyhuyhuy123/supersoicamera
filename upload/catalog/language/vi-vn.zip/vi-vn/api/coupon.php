<?php
// Text
$_['text_success']     = 'Thành công: Giảm giá của bạn đã được áp dụng!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào API!';
$_['error_coupon']     = 'Cảnh báo: Phiếu giảm giá là không hợp lệ, đã hết hạn hoặc đạt đến giới hạn sử dụng của nó!';