<?php
// Text
$_['text_currency'] = 'Tiền tệ';