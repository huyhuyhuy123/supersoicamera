<?php
// Text
$_['text_home']     = 'Trang chủ';$_['text_blogs']           = 'Blogs';
$_['text_wishlist'] = 'Mặt hàng yêu thích (%s)';
$_['text_shopping_cart']  = 'Đơn hàng';$_['text_blog']           = 'Blogs tin tức';
$_['text_category']      = 'Danh mục';
$_['text_account']       = 'Tài khoản của tôi';
$_['text_register']      = 'Đăng ký';
$_['text_login']         = 'Đăng nhập';
$_['text_order']         = 'Lịch sử đặt hàng';
$_['text_transaction']   = 'Giao dịch';
$_['text_download']      = 'Tải về';
$_['text_logout']        = 'Đăng xuất';
$_['text_checkout']      = 'Thanh Toán';
$_['text_search']        = 'Tìm kiếm';
$_['text_all']           = 'Thấy tất cả';