<?php
// Heading
$_['heading_title']    = 'Tài khoản';

// Text
$_['text_register']    = 'Đăng ký';
$_['text_login']       = 'Đăng nhập';
$_['text_logout']      = 'Đăng xuất';
$_['text_forgotten']   = 'Quên tài khoản';
$_['text_account']     = 'Tài khoản của tôi';
$_['text_edit']        = 'Chỉnh sửa tài khoản';
$_['text_password']    = 'Mật khẩu';
$_['text_address']     = 'Sổ tay địa chỉ';
$_['text_wishlist']    = 'Danh sách yêu thích';
$_['text_order']       = 'Lịch sử đặt hàng';
$_['text_download']    = 'Tải về';
$_['text_reward']      = 'Điểm thưởng';
$_['text_return']      = 'Trả về';
$_['text_transaction'] = 'Giao dịch';
$_['text_newsletter']  = 'Bản tin';
$_['text_recurring']   = 'Thanh toán định kỳ';