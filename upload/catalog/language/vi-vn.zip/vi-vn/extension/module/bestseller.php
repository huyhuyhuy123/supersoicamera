<?php
// Heading
$_['heading_title'] = 'Bán chạy nhất';

// Text
$_['text_tax']      = 'Ex Tax:';