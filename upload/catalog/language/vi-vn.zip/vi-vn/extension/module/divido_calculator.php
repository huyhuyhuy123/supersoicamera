<?php
// Calculator
$_['text_checkout_title']      = 'Trả tiền';
$_['text_choose_plan']         = 'Chọn kế hoạch của bạn';
$_['text_choose_deposit']      = 'Chọn khoản tiền gửi của bạn';
$_['text_monthly_payments']    = 'Thanh toán hàng tháng';
$_['text_months']              = 'Tháng';
$_['text_term']                = 'Kỳ hạn';
$_['text_deposit']             = 'Tiền gửi';
$_['text_credit_amount']       = 'Chi phí tín dụng';
$_['text_amount_payable']      = 'Tổng số phải trả';
$_['text_total_interest']      = 'Tổng số tiền lãi APR';
$_['text_monthly_installment'] = 'Trả góp hằng tháng';
$_['text_redirection']         = 'Bạn sẽ được chuyển hướng đến Divido để hoàn thành đơn đăng ký tài chính này khi bạn xác nhận đơn hàng của bạn';