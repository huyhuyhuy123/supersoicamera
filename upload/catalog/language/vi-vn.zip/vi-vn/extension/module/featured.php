<?php
// Heading
$_['heading_title'] = 'Tính năng';

// Text
$_['text_tax']      = 'Ex Tax:';