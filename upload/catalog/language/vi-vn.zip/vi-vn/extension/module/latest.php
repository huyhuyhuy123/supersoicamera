<?php
// Heading
$_['heading_title'] = 'Muộn nhất';

// Text
$_['text_tax']      = 'Ex Tax:';