<?php
// Text
$_['text_total'] = 'Total';