<?php
// Heading
$_['heading_title']    = 'Sơ đồ trang';
 
// Text
$_['text_special']     = 'Khuyến mại';
$_['text_account']     = 'Tài khoản';
$_['text_edit']        = 'Thông tin tài khoản';
$_['text_password']    = 'Mật khẩu';
$_['text_address']     = 'Sổ địa chỉ';
$_['text_history']     = 'Lịch sử mua hàng';
$_['text_download']    = 'Tải về';
$_['text_cart']        = 'Giỏ hàng';
$_['text_checkout']    = 'Thanh toán';
$_['text_search']      = 'Tìm kiếm';
$_['text_information'] = 'Thông tin ';
$_['text_contact']     = 'Liên hệ';