<?php
// Text
$_['text_subject']      = '%s - Cập nhật đơn hàng %s';
$_['text_order_id']     = 'ID đơn hàng:';
$_['text_date_added']   = 'Date Added:';
$_['text_order_status'] = 'Đơn đặt hàng của bạn đã được cập nhật với trạng thái sau:';
$_['text_comment']      = 'Nhận xét về đơn đặt hàng của bạn là:';
$_['text_link']         = 'Để xem đơn đặt hàng của bạn, hãy nhấp vào liên kết bên dưới:';
$_['text_footer']       = 'Vui lòng trả lời email này nếu bạn có thắc mắc.';