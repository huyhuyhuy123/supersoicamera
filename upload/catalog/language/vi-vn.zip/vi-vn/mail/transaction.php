<?php
// Text
$_['text_subject']  = '%s - Đại lý ủy quyền';
$_['text_received'] = 'Xin chúc mừng! Bạn đã nhận được khoản thanh toán hoa hồng từ chương trình đại lý %s ';
$_['text_amount']   = 'Bạn đã nhận được:';
$_['text_total']    = 'Tổng số tiền hoa hồng của bạn bây giờ:';