

<?php
// Text
$_['text_upload']    = 'Tập tin của bạn đã được tải lên thành công!';

// Error
$_['error_filename'] = 'Tên tệp phải có từ 3 đến 64 ký tự!';
$_['error_filetype'] = 'Loại tệp không hợp lệ!';
$_['error_upload']   = 'Yêu cầu tải lên!';